MAC Layer
=========
1. The attached ZIP contains Angular and Java part too.
2. We are using H2 database.
3. The credentials for logging into MAC Layer are:
	username: prerak
	password: prerak

Thanks